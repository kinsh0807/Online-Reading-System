package com.masai.library.app.Main;

import com.masai.library.app.entity.Book;
import com.masai.library.app.entity.User;
import com.masai.library.app.System.OnlineReaderSystem;

public class Main {

    public static void main(String[] args) {


    OnlineReaderSystem onlineReaderSystem = new OnlineReaderSystem();

    Book book = new Book(101, "Harry Potter", "Book by JK Rowling", 500);
    User user = new User(101, "Alpha");

    User user2 = new User(103, "Beta");
    onlineReaderSystem.getUserManager().addUser(user);
    onlineReaderSystem.setUser(user2);
    onlineReaderSystem.setBook(book);
    onlineReaderSystem.getDisplay();
    onlineReaderSystem.getDisplay().nextPage();
    onlineReaderSystem.getDisplay().refreshPage();


    System.out.println(book);
}


}
