package com.masai.library.app.System;

import com.masai.library.app.entity.Book;
import com.masai.library.app.entity.User;
import com.masai.library.app.Dashboard.Dashboard;
import com.masai.library.app.Utils.Library;
import com.masai.library.app.Utils.UserManager;

public class OnlineReaderSystem {

    private Library library;
    private UserManager userManager;
    private Dashboard display;

    public OnlineReaderSystem() {
        library = new Library();
        userManager = new UserManager();
        display = new Dashboard();
    }

    public Book getBook(int bookId) {
        return library.findBook(bookId);
    }

    public User getUser(int userId) {
        return userManager.findUser(userId);
    }

    public void setBook(Book book) {
        display.setBook(book);
    }

    public void setUser(User user) {
        display.setUser(user);
    }

    public Dashboard getDisplay() {
        return display;
    }
    public UserManager getUserManager() {
        return userManager;
    }
}
